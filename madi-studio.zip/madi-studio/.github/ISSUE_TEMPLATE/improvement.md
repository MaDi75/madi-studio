---
name: Improvement
about: A small upgrade to the current app
title: "[IMPROVEMENT] "
labels: enhancement
assignees: ''
---

## What should improve


## Why


## How it could work

---

## Что стоит улучшить


## Почему


## Как это может работать
