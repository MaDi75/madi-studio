---
name: Feature request
about: Suggest an idea for MaDi Studio
title: "[FEATURE] "
labels: enhancement
assignees: ''
---

**What would you like**


**Why it helps**


**Any alternative**


---

**Что хочется добавить**


**Зачем это нужно**


**Есть ли другой вариант**
