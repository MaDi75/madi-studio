---
name: Bug report
about: Something in MaDi Studio does not work
title: "[BUG] "
labels: bug
assignees: ''
---

**What happened**
A short description.

**Steps**
1. Open ...
2. Choose ...
3. See ...

**What you expected**


**Browser and device**
- Browser:
- OS:

**Extra notes**
Screenshots help.

---

**Что случилось**
Короткое описание.

**Шаги**
1. Открыл ...
2. Выбрал ...
3. Увидел ...

**Что ожидалось**


**Браузер и устройство**
- Браузер:
- ОС:

**Дополнительно**
Скриншоты помогают.
